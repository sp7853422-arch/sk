# Student Pass/Fail Prediction Project

This project uses machine learning to predict whether a student will
pass or fail based on: - Study Hours - Attendance - Internal Marks

## How to Run

1.  Install requirements:

        pip install -r requirements.txt

2.  Run the project:

        python main.py

## Files Included

-   main.py
-   student_pass_fail_dataset.csv
-   requirements.txt
-   model.pkl (auto-generated)
